
An Online Shopping website developed using Html, CSS, Bootstrap, MySQL, PHP.<br>


Features
--------

* All forms validated on Client side using HTML5 and on Server side using PHP.
* Responsive and nice looking webpages 

Running the project 
-------------------

* Install WAMP
* Import database from store.sql file.
* Copy the Fashion Folder to C:\wamp64\www\
* Run WAMP and open web page from browser: http://localhost/Fashion/index.php

Project Developer
----------------
Ram Mohan
